<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CorsMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  Closure(Request): (Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Headers CORS pour toutes les réponses
        $headers = [
            'Access-Control-Allow-Origin' => '*',
            'Access-Control-Allow-Methods' => 'GET, POST, PUT, DELETE, OPTIONS, PATCH',
            'Access-Control-Allow-Headers' => 'Content-Type, Authorization, X-Requested-With, X-CSRF-TOKEN, X-XSRF-TOKEN, Accept, Origin, Cache-Control',
            'Access-Control-Allow-Credentials' => 'true',
            'Access-Control-Max-Age' => '86400',
        ];

        // Gérer les requêtes OPTIONS (pre-flight) d'abord
        if ($request->getMethod() === 'OPTIONS') {
            return response('', 200, $headers);
        }
        
        // Ajoute les headers CORS à la réponse
        $response = $next($request);
        
        // Ajouter les headers CORS à tous les types de réponse
        if ($response instanceof \Illuminate\Http\Response) {
            foreach ($headers as $key => $value) {
                $response->headers->set($key, $value);
            }
        } elseif ($response instanceof \Symfony\Component\HttpFoundation\Response) {
            foreach ($headers as $key => $value) {
                $response->headers->set($key, $value);
            }
        }
        
        return $response;
    }
}
