<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $query = Product::with('category');

        // Filtre par catégorie
        if ($request->has('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        // Recherche par nom
        if ($request->has('search')) {
            $search = $request->search;
            $query->where('name', 'LIKE', "%{$search}%");
        }

        $products = $query->paginate($request->per_page ?? 15);

        return response()->json($products);
    }

    public function show($id)
    {
        $product = Product::with(['category', 'stocks.pharmacy'])
            ->findOrFail($id);

        return response()->json($product);
    }

    public function search(Request $request)
    {
        $query = $request->get('query');
        
        if (!$query) {
            return response()->json(['error' => 'Query parameter is required'], 422);
        }

        $latitude = $request->latitude;
        $longitude = $request->longitude;
        $radius = $request->radius ?? 10;
        $minRating = $request->min_rating;
        $minPrice = $request->min_price;
        $maxPrice = $request->max_price;
        $deliveryOnly = $request->delivery_available;

        // Recherche des produits avec jointures optimisées
        $productsQuery = Product::where('name', 'LIKE', "%{$query}%")
            ->with(['category', 'stocks.pharmacy'])
            ->whereHas('stocks', function($stockQuery) use ($minPrice, $maxPrice) {
                $stockQuery->where('quantity', '>', 0);
                
                if ($minPrice) {
                    $stockQuery->where('price', '>=', $minPrice);
                }
                
                if ($maxPrice) {
                    $stockQuery->where('price', '<=', $maxPrice);
                }
            });

        $products = $productsQuery->get()->map(function($product) use ($latitude, $longitude, $radius, $minRating, $deliveryOnly) {
            $availablePharmacies = $product->stocks->filter(function($stock) {
                return $stock->quantity > 0;
            })->map(function($stock) use ($latitude, $longitude, $radius) {
                $pharmacy = $stock->pharmacy;
                
                // Calcul de distance si coordonnées fournies
                if ($latitude && $longitude) {
                    $distance = $this->calculateDistance(
                        $latitude, $longitude,
                        $pharmacy->latitude, $pharmacy->longitude
                    );
                    $pharmacy->distance = $distance;
                }

                return [
                    'pharmacy' => $pharmacy,
                    'stock' => [
                        'quantity' => $stock->quantity,
                        'price' => $stock->price
                    ]
                ];
            });

            // Filtres additionnels
            if ($minRating) {
                $availablePharmacies = $availablePharmacies->filter(function($item) use ($minRating) {
                    return $item['pharmacy']->rating >= $minRating;
                });
            }

            if ($deliveryOnly) {
                $availablePharmacies = $availablePharmacies->filter(function($item) {
                    return $item['pharmacy']->delivery_available;
                });
            }

            if ($latitude && $longitude && $radius) {
                $availablePharmacies = $availablePharmacies->filter(function($item) use ($radius) {
                    return $item['pharmacy']->distance <= $radius;
                })->sortBy('pharmacy.distance');
            }

            return [
                'product' => $product,
                'available_pharmacies' => $availablePharmacies->values(),
                'total_pharmacies' => $availablePharmacies->count(),
                'min_price' => $availablePharmacies->pluck('stock.price')->min(),
                'max_price' => $availablePharmacies->pluck('stock.price')->max()
            ];
        })->filter(function($result) {
            return $result['total_pharmacies'] > 0;
        })->values();

        return response()->json([
            'query' => $query,
            'results' => $products,
            'total_results' => $products->count()
        ]);
    }

    private function calculateDistance($lat1, $lon1, $lat2, $lon2)
    {
        $earthRadius = 6371; // km

        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);

        $a = sin($dLat/2) * sin($dLat/2) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLon/2) * sin($dLon/2);
        $c = 2 * asin(sqrt($a));
        $distance = $earthRadius * $c;

        return round($distance, 2);
    }
}
