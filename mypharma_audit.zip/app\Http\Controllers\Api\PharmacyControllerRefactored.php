<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\GetPharmaciesRequest;
use App\Http\Resources\PharmacyResource;
use App\Models\Pharmacy;
use App\Services\PharmacyService;
use Illuminate\Http\JsonResponse;

class PharmacyControllerRefactored extends Controller
{
    private PharmacyService $pharmacyService;

    public function __construct(PharmacyService $pharmacyService)
    {
        $this->pharmacyService = $pharmacyService;
    }

    /**
     * Lister les pharmacies avec filtres
     */
    public function index(GetPharmaciesRequest $request): JsonResponse
    {
        $pharmacies = $this->pharmacyService->getPharmacies($request->validated());

        return response()->json($pharmacies);
    }

    /**
     * Afficher une pharmacie spécifique
     */
    public function show(int $id): JsonResponse
    {
        $pharmacy = $this->pharmacyService->getPharmacyById($id);

        return response()->json(new PharmacyResource($pharmacy));
    }

    /**
     * Lister les avis d'une pharmacie
     */
    public function reviews(int $id, Request $request): JsonResponse
    {
        $perPage = $request->get('per_page', 10);
        $reviews = $this->pharmacyService->getPharmacyReviews($id, $perPage);

        return response()->json($reviews);
    }
}
