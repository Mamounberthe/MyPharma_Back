<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreOrderRequest;
use App\Http\Requests\UpdateOrderStatusRequest;
use App\Http\Resources\OrderResource;
use App\Models\Order;
use App\Services\OrderService;
use Illuminate\Http\JsonResponse;

class OrderControllerRefactored extends Controller
{
    private OrderService $orderService;

    public function __construct(OrderService $orderService)
    {
        $this->orderService = $orderService;
    }

    /**
     * Lister les commandes de l'utilisateur
     */
    public function index(Request $request): JsonResponse
    {
        $orders = $this->orderService->getUserOrders(
            $request->user()->id,
            $request->get('per_page', 10)
        );

        return response()->json($orders);
    }

    /**
     * Créer une nouvelle commande
     */
    public function store(StoreOrderRequest $request): JsonResponse
    {
        try {
            $order = $this->orderService->createOrder(
                $request->validated(),
                $request->user()->id
            );

            return response()->json([
                'message' => 'Commande créée avec succès',
                'order' => new OrderResource($order)
            ], 201);

        } catch (\InvalidArgumentException $e) {
            return response()->json([
                'error' => 'Données invalides',
                'message' => $e->getMessage()
            ], 422);

        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Erreur lors de la création de la commande',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Afficher une commande spécifique
     */
    public function show(Order $order, Request $request): JsonResponse
    {
        // Vérifier que l'utilisateur est bien le propriétaire
        if ($order->user_id !== $request->user()->id) {
            return response()->json(['error' => 'Non autorisé'], 403);
        }

        return response()->json(new OrderResource($order));
    }

    /**
     * Mettre à jour le statut d'une commande
     */
    public function updateStatus(Order $order, UpdateOrderStatusRequest $request): JsonResponse
    {
        try {
            $updatedOrder = $this->orderService->updateOrderStatus(
                $order,
                $request->validated()['status']
            );

            return response()->json([
                'message' => 'Statut mis à jour avec succès',
                'order' => new OrderResource($updatedOrder)
            ]);

        } catch (\InvalidArgumentException $e) {
            return response()->json([
                'error' => 'Statut invalide',
                'message' => $e->getMessage()
            ], 422);
        }
    }

    /**
     * Vérifier si l'utilisateur peut mettre à jour le statut
     */
    private function authorizeStatusUpdate(Order $order, $user): void
    {
        // Client : peut annuler seulement ses propres commandes
        if ($user->isClient()) {
            if ($order->user_id !== $user->id || request('status') !== 'cancelled') {
                abort(403, 'Non autorisé');
            }
            return;
        }

        // Livreur/Admin : peut mettre à jour tous les statuts
        if ($user->isLivreur() || $user->isAdmin()) {
            return;
        }

        abort(403, 'Non autorisé');
    }
}
