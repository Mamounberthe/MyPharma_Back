<?php

namespace App\Services;

use App\Models\Pharmacy;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Pagination\LengthAwarePaginator;

class PharmacyService
{
    /**
     * Récupérer les pharmacies avec filtres
     */
    public function getPharmacies(array $filters = []): LengthAwarePaginator
    {
        $query = Pharmacy::with(['reviews' => function($query) {
            $query->latest()->limit(5);
        }]);

        // Filtre par distance
        if (isset($filters['latitude']) && isset($filters['longitude'])) {
            $lat = $filters['latitude'];
            $lng = $filters['longitude'];
            $radius = $filters['radius'] ?? 10;

            $query->selectRaw(
                "*, (6371 * acos(cos(radians(?)) * cos(radians(latitude)) * cos(radians(longitude) - radians(?)) + sin(radians(?)) * sin(radians(latitude)))) AS distance",
                [$lat, $lng, $lat]
            )->having('distance', '<=', $radius)->orderBy('distance');
        }

        // Filtre par note minimale
        if (isset($filters['min_rating'])) {
            $query->where('rating', '>=', $filters['min_rating']);
        }

        // Filtre par disponibilité livraison
        if (isset($filters['delivery_available'])) {
            $query->where('delivery_available', $filters['delivery_available']);
        }

        // Tri
        $sortBy = $filters['sort_by'] ?? 'rating';
        $sortOrder = $filters['sort_order'] ?? 'desc';

        if (in_array($sortBy, ['rating', 'name', 'created_at'])) {
            $query->orderBy($sortBy, $sortOrder);
        }

        return $query->paginate($filters['per_page'] ?? 15);
    }

    /**
     * Récupérer une pharmacie par ID avec ses relations
     */
    public function getPharmacyById(int $id): Pharmacy
    {
        return Pharmacy::with(['reviews.user', 'stocks.product.category'])
            ->findOrFail($id);
    }

    /**
     * Récupérer les avis d'une pharmacie
     */
    public function getPharmacyReviews(int $id, int $perPage = 10): LengthAwarePaginator
    {
        $pharmacy = Pharmacy::findOrFail($id);

        return $pharmacy->reviews()
            ->with('user:id,name')
            ->latest()
            ->paginate($perPage);
    }

    /**
     * Calculer la distance entre deux points géographiques
     */
    private function calculateDistance(float $lat1, float $lon1, float $lat2, float $lon2): float
    {
        // TODO : Implémenter le calcul de distance Haversine
        // Même logique que dans ProductController
        $earthRadius = 6371; // Rayon de la Terre en km
        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);
        $a = sin($dLat / 2) * sin($dLat / 2) +
             cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
             sin($dLon / 2) * sin($dLon / 2);
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        return $earthRadius * $c;
    }
}
